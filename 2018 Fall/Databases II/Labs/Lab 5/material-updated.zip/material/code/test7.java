import java.sql.*;
import java.util.ArrayList;


public class test7 {
    public static void main( String args[] )
    {
        ArrayList<Integer> ages = new ArrayList<Integer>();

        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.postgresql.Driver");
            c = DriverManager
                    .getConnection("jdbc:postgresql://localhost:5432/test",
                            "postgres", "123456");
            c.setAutoCommit(false);
            System.out.println("Opened database successfully");

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery( "SELECT age FROM COMPANY;" );

            while ( rs.next() ) {
                int age = rs.getInt("age");
                ages.add(age);
            }
            System.out.println("ages are: "+ages);
            rs.close();
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
            System.exit(0);
        }

        double sum = 0.0;

        for(int i = 0; i<ages.size();i++){
            sum = sum+ages.get(i);
        }
        System.out.println("sum of ages is: "+sum);

        double mean = sum/ages.size();
        System.out.println("mean of ages is: "+mean);

        double vsum = 0.0;
        for(int i = 0; i<ages.size();i++){
            vsum = vsum+Math.pow(ages.get(i)- mean,2);
        }

        double variance = vsum/ages.size();
        System.out.println("variance of ages is: "+variance);

        double stand_deviation = Math.sqrt(variance);
        System.out.println("standard deviation of ages is: "+stand_deviation);

        System.out.println("Operation done successfully");
    }
}
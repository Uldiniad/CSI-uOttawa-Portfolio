Oliver Charles Scott	7931937
Mohammad Hadi		7718721

1. Run Server.java
2. Run Client.java
3. Enter a string of 0s and 1s into the console (it will accept other strings but will not encode them)

The client will encode the string and print it. It will then send it to the server. Finally, it will print the reply from the server.
The server will receive the encoded string from the client and print it. It will then decode the string and print it.
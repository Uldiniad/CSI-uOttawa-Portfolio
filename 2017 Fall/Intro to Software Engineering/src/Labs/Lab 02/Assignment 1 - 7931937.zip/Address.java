public class Address {
    private int number;
    private String street;
    private String postal;

    public Address(int number, String street, String postal) {
        this.number = number;
        this.street = street;
        this.postal = postal;
    }
}
